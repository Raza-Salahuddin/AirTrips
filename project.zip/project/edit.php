<?php

session_start();


  ?>
  <!DOCTYPE html>
  <html>
  <head>
  	<title> <?php echo" " .$_SESSION["uname"].""?></title>
  </head>
  
  <body>
  
  </body>
  </html>