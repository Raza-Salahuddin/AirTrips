<html>
<head>
<?php
session_start();
?>
	<title>Eden Touristor</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="a.css">
<style>
body,h1,h2,h3,h4,h5,h6,a {font-family: "Raleway", Arial, Helvetica, sans-serif }

.myLink {display: none}
</style>
<head>
  <style type="text/css">
    /* Dropdown Button */
table {
  border-collapse: collapse;
  width: 100%;}
  th, td {
  text-align: left;
  padding: 6px;
  font-weight: bold;
 text-transform: capitalize;
  font-size: 12px;}
  th {

  background-color: #EC4D2B;
  color: white;
}
.hero-image {
  background-image: url("paris.jpg");
  background-color: #cccccc;
  height: 100%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}
.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
tr:nth-child(odd){background-color: #ced9db;}
tr:nth-child(even){background-color: #f2f2f2;}




  


  </style>
</head>
<body  >
<div class="w3-bar w3-white w3-border-bottom w3-xlarge">
  <a href="mainpage.php"  class="w3-bar-item w3-button w3-text-red w3-hover-red"><b><i class="fa fa-map-marker w3-margin-right"></i>Eden Tourister <sub>Leading All-Ways</sub> </b>  </a> 
  
   
    
 
</div>

<div class="divi">
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Packages</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Reservations</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge" >Gallery</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Chat Room</button>
  <div class="dropdown-content">
    <a href="createtrips.php">Create Trip</a>
    <a href="#">Ask questions</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">About Us</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge"><i class="fa fa-bars"><?php echo" " .$_SESSION["uname"].""?></i></button>
  <div class="dropdown-content">
    <a href=""><?php echo"" .$_SESSION["uname"].""?></a>
     <a href="logout.php">Logout</a>
    
    <a href="#">Settings</a>
    <a href="#">Help</a>
   
   </div>
</div>

<div class="hero-image">
  <div class="hero-text">
 <h2>Flights Name and Price </h2>

    	
	<?php 

$from = $_POST['departure'];
$to = $_POST['arriving'];
$query = "SELECT * from Flights";

		$connection=mysqli_connect("localhost","root","","login");

		$result       =     mysqli_query($connection, $query);
		//$row1= 				mysqli_fetch_array($result);

?>

<?php 

 ?>
 <br>
<table>
  <tr>
    
		<th>Flight Name</th>
		<th>Departure</th>
		<th>Arrival</th>
		<th>Date and Time</th>
		
		<th>Price</th>
  </tr>
 <?php

		
		while($row    =     mysqli_fetch_array($result))
		{
			
			
			
			$time     =     $row[1];
			$Departure   =     $row[2];
			$Arrival =     $row[3];
			$Flightname      =     $row[4];

	?>
				
				<td align="center"><?php echo $Flightname; ?></td>
				<td align="center"><?php echo $time; ?></td>
				<td align="center"><?php echo $Departure; ?></td>
				<td align="center"><?php echo $Arrival; ?></td>
				<td align="center"> Updated Soon</td>


		
	</tr>
	<?php } ?>


</table>
</div>

</div>


</body>

</html>