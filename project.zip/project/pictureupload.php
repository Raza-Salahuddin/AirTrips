<?php
$conn = new mysqli('localhost', 'root', '', 'login');
if ($conn->connect_error) { // Check connection
 die("Connection failed: " . $conn->connect_error);
} 

if(isset($_FILES["attachment"]["error"])){
   if($_FILES["attachment"]["error"] > 0){
      echo "Error: ".$_FILES["attachment"]["error"]; 
   }else {
    // File Type Restrictions
    $filename = $_FILES["attachment"]["name"];
    $allowed = array( 'jpg', 'jpeg', 'gif', 'png', 'bmp');
    $ext = pathinfo($filename, PATHINFO_EXTENSION); 
    if(!in_array($ext, $allowed)) 
        die("Error: Please select a valid file format.-".$ext);
      // File size Resctrictions
    $maxsize = 2 * 1024 * 1024; //2MB maximum allowed.
    $filesize= $_FILES["attachment"]["size"];
    if($filesize > $maxsize) 
        die("Error: File size is larger than the allowed limit.");
       $uploads_dir = "upload/";
    if(file_exists($uploads_dir. $_FILES["attachment"]["name"])){ 
        echo $_FILES["attachment"]["name"] . " is already exists. Please Rename and Upload it again"; 
    } else{   
        move_uploaded_file($_FILES["attachment"]["tmp_name"], $uploads_dir. $_FILES["attachment"]["name"]); 
        mysqli_query($conn, "INSERT INTO images (filename, type, size, date) values ( '".$_FILES["attachment"]["name"]."', '".$_FILES["attachment"]["type"]."', '".$_FILES["attachment"]["size"]."', '".date('Y-m-d h:i:sa')."')");
        if(mysqli_insert_id($conn)){
            echo ' Successfully Inserted #'.mysqli_insert_id($conn); 
        }}}}
$conn->close();?>


<html>
<head>
  <script type="text/javascript">
    
// Tabs
function openLink(evt, linkName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("myLink");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
  }
  document.getElementById(linkName).style.display = "block";
  evt.currentTarget.className += " w3-red";
}

// Click on the first tablink on load
document.getElementsByClassName("tablink")[0].click();
</script>

  <title> login or sign up</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="a.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", Arial, Helvetica, sans-serif}
.myLink {display: none}
</style>
</head>
<body class="w3-light-grey">
  <!-- Navigation Bar -->
<div class="w3-bar w3-white w3-border-bottom w3-xlarge">
  <a href="#" class="w3-bar-item w3-button w3-text-red w3-hover-red"><b><i class="fa fa-map-marker w3-margin-right"></i>Eden Tourister <sub>Leading All-Ways</sub> </b>  </a> 
  <a href="#" class="w3-bar-item w3-button w3-right w3-hover-red w3-text-grey"><i class="fa fa-search"></i></a>

</div>
<div class="divi">
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Packages</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Reservations</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge" >Gallery</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Chat Room</button>
  <div class="dropdown-content">
    <a href="createtrips.php">Create Trip</a>
    <a href="#">Ask questions</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">About Us</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge"><i class="fa fa-bars"></i></button>
  <div class="dropdown-content">
    <a href="pictureupload.php">Upload Picture</a>
    
    <a href="#">Settings</a>
    <a href="#">Help</a>
   
   </div>
</div>
</div>
<!-- Header -->
<header class="w3-display-container w3-content w3-hide-small" style="max-width:1500px">
  <img class="w3-image" src="attaabadlake.jpg"  width="1500" height="700">
  <div class="w3-display-middle" style="width:65%">

     <div class="w3-display-middle" style="width:65% height 100%">
    <div class="w3-bar w3-green">
      <button class="w3-bar-item w3-button tablink" onclick="openLink(event, 'Flight');"><i class="fa fa-plane w3-margin-right"></i>Upload your picture</button>
      <button class="w3-bar-item w3-button tablink" onclick="openLink(event, 'Hotel');"><i class="fa fa-cloud w3-margin-right"></i>Sign up</button>
    </div>
    <!-- Tabs -->
    <div id="Flight" class="w3-container w3-white w3-padding-16 myLink">
      <h3>Upload Picture to Gallery</h3>
      <div class="w3-row-padding" style="margin:0 -16px;">
        <div class="w3-half">
<form action="pictureupload.php" method="post" enctype="multipart/form-data">
 <input type="file" name="attachment" class="w3-bar-item w3-button w3-hover-green" > 
 <input class="w3-bar-item w3-button w3-hover-green"  type="submit" name="HandleUpload" value="Upload" >
</form>

        
        
       
       

      </div>
      
    </div>

   

  <!-- Footer -->
  
<footer class="w3-container w3-center w3-opacity w3-margin-bottom">
  <h5>Find Us On</h5>
  <div class="w3-xlarge w3-padding-16">
    <i class="fa fa-facebook-official w3-hover-opacity"></i>
    <i class="fa fa-instagram w3-hover-opacity"></i>
    <i class="fa fa-snapchat w3-hover-opacity"></i>
    <i class="fa fa-pinterest-p w3-hover-opacity"></i>
    <i class="fa fa-twitter w3-hover-opacity"></i>
    <i class="fa fa-linkedin w3-hover-opacity"></i>
  </div>
 <h4> Our Vision. To strengthen our position as the leading tourism company providing quality, creative, innovative, competitive and socially responsible services in the region.</h4>

</footer>

</body>
</html>