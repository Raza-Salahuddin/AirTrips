
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$first_name = mysqli_real_escape_string($link, $_REQUEST['fname']);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
$usernam = mysqli_real_escape_string($link, $_REQUEST['username']);
$password =mysqli_real_escape_string($link, $_REQUEST['password']);
$address =mysqli_real_escape_string($link, $_REQUEST['address']);
	$phone =mysqli_real_escape_string($link, $_REQUEST['phone']);

 
// Attempt insert query execution
$sql = "INSERT INTO register (fname, phone, password ,address,email,usernam) VALUES ('$first_name', '$phone','$password','$address','$email','$usernam')";
if(mysqli_query($link, $sql)){
    echo "Registration successfull!.";
      header('Location: loginorsignup.html');


} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>