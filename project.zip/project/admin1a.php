<!----------------------------------------------Start ofPHP for Insertion----------------------------------------->
<?php 
session_start();


$link = mysqli_connect("localhost", "root", "", "login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$Flight = mysqli_real_escape_string($link, $_REQUEST['fname']);
$departre = mysqli_real_escape_string($link, $_REQUEST['departre']);
$arriving = mysqli_real_escape_string($link, $_REQUEST['arriving']);
$time =mysqli_real_escape_string($link, $_REQUEST['time']);


 
// Attempt insert query execution
$sql = "INSERT INTO flights (frm, too, dtime ,flight) VALUES ('$departre', '$arriving','$time','$Flight')";
if(mysqli_query($link, $sql)){
    echo "inserted successfully!.";
      header('Location: admin1.php');
      


} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);



 ?>
<!----------------------------------------------End of PHP for Insertion------------------------------------------>



