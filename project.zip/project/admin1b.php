<!----------------------------------------------Start ofPHP for Insertion----------------------------------------->
<?php 
session_start();


$link = mysqli_connect("localhost", "root", "", "login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$Flight = mysqli_real_escape_string($link, $_REQUEST['fname']);
$departre = mysqli_real_escape_string($link, $_REQUEST['departre']);
$arriving = mysqli_real_escape_string($link, $_REQUEST['arriving']);
$time =mysqli_real_escape_string($link, $_REQUEST['time']);
$id= mysqli_real_escape_string($link, $_REQUEST['ide']);
 
// Attempt insert query execution    "UPDATE `table_name` SET `column_name` = `new_value' [WHERE condition];"
$sql = " UPDATE flights
 SET frm='$departre', too ='$arriving', dtime = '$time' , flight = '$Flight' where id = '$id'";
if(mysqli_query($link, $sql)){
    echo "inserted successfully!.";
      header('Location: admin1.php');
      


} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);



 ?>
<!----------------------------------------------End of PHP for Insertion------------------------------------------>



