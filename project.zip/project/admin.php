<!DOCTYPE html>
<html>
<head>
	<title> Admins panel Login</title>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="a.css">
<style>
body,h1,h2,h3,h4,h5,h6,a {font-family: "Raleway", Arial, Helvetica, sans-serif}
.myLink {display: none}
</style>
</head>
<body>
<?php




  ?>
<head>
  <style type="text/css">
    /* Dropdown Button */


  



  </style>
</head>
<body class="w3-light-grey">

<!-- Navigation Bar -->
<div class="w3-bar w3-white w3-border-bottom w3-xlarge">
  <a href="#" class="w3-bar-item w3-button w3-text-red w3-hover-red"><b><i class="fa fa-map-marker w3-margin-right"></i>Eden Tourister <sub>Leading All-Ways</sub> </b>  </a> 
  
   
    
 
</div>

<div class="divi">
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Packages</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Reservations</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge" >Gallery</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Chat Room</button>
  <div class="dropdown-content">
    <a href="createtrips.php">Create Trip</a>
    <a href="#">Ask questions</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">About Us</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>

    
    
   
   </div>
</div>
</div>
<br><br>


	<div style="margin-left: 25%;" class="row">
		<div  style=" float: center; padding: 10px; width: 50%;height: 20%; background-color: lightgreen;" class="col-xs-12 col-sm-6 col-md-8">
			<form action="admin.php" method="POST">
	<h1 style="font-family: times new roman; font-size: 72px,auto; font-weight: bold;"> Login as Admin</h1><br>
	<input type="text" name="adminusername" id="adminusername" placeholder="Admin Username" class="form-control">

 	<input type="password" name="adminpassword" id="adminpassword" placeholder="Admin Password" class="form-control">
 		<button value="Login"> submit</button>
			</form>
			
		</div>
	</div>


</body>
</html>
<?php 
$message = "Invalid Username or Password!";
			$usradmin = $_POST['adminusername'];
			$pswadmin = $_POST['adminpassword'];
			$usradmin = stripcslashes($usradmin);
			$pswadmin = stripcslashes($pswadmin);
			if($usradmin=='raza'&& $pswadmin == '1122')
			{
				session_start();
				$_SESSION["uname"]=$usradmin;
				
				  header('Location:admin1.php');

			}
			else
			{
echo "<script type='text/javascript'>alert('$message');</script>"; 			}


 	
 	
?>