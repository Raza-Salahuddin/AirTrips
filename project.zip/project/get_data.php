<?php
 $lat=$_POST['latitude'];
  $long=$_POST['longitude'];
session_start();
$_SESSION['lati']=$lat;
$_SESSION['longi']=	$long;


$conn = mysqli_connect("localhost","root","","login");

                // Check connection
                if (mysqli_connect_errno())
                {
               echo "Failed to connect to MySQL: " . mysqli_connect_error();
                }
  $sql= (" INSERT INTO coordinates (longitude, latitude) VALUES ('$lat', '$long')");
if(mysqli_query($conn, $sql)){
    echo "captain will be there ASAP.";
      header('Location: mainpage.php');


} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
 
?>