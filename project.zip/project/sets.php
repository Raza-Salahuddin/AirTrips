<?php
$username = $_POST['user'];
$password = $_POST['pass'];
$_SESSION['counter'];
$remember = $_POST['remember'];
$conn= mysqli_connect("localhost", "root", "", "login");
$password = stripcslashes($password);
$username = mysqli_real_escape_string($conn,$username);
$password = mysqli_real_escape_string($conn,$password);
$escapedRemember=mysqli_real_escape_string($conn,$remember);

$sql= mysqli_query($conn,"SELECT * FROM register where usernam = '$username' AND password='$password'" )
or die("failed to query database".mysqli_error($conn));
$row =mysqli_fetch_array($sql);
if (($row['usernam']==$username) && ($row['password']==$password ))
{
	session_start();
// Set session variables
$_SESSION["uname"] = $username;
$_SESSION["pword"] = $password;

echo "Session variables are set.";
  header('Location: mainpage.php');
}
else
{
  header('Location:loginorsignup.html');
}

// Start the session

?>