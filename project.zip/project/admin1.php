<?php  
session_start();

?>

<html>
<head>
	<title> Admin Panel</title>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="a.css">
<link rel="stylesheet" type="text/css" href="schedule.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", Arial, Helvetica, sans-serif}
.myLink {display: none}
</style>
<style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
 <style type="text/css">
    /* Dropdown Button */
table {
  border-collapse: collapse;
  width: 100%;}
  th, td {
  text-align: left;
  padding: 6px;
  font-weight: bold;
 text-transform: capitalize;
  font-size: 12px;}
  th {

  background-color: #EC4D2B;
  color: white;
}
.hero-image {
  background-image: url("paris.jpg");
  background-color: #cccccc;
  height: 100%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}
.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
tr:nth-child(odd){background-color: #ced9db;}
tr:nth-child(even){background-color: #f2f2f2;}




  


  </style>
</head>
<body class="w3-light-grey">

<!-- Navigation Bar -->
<div class="w3-bar w3-white w3-border-bottom w3-xlarge">
  <a href="#" class="w3-bar-item w3-button w3-text-red w3-hover-red"><b><i class="fa fa-map-marker w3-margin-right"></i>Eden Tourister <sub>Leading All-Ways</sub> </b>  </a> 
  
   
    
 
</div>

<div class="divi">
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Packages</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Reservations</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge" >Gallery</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">Chat Room</button>
  <div class="dropdown-content">
    <a href="createtrips.php">Create Trip</a>
    <a href="#">Ask questions</a>
    <a href="#">Link 3</a>
  </div>
</div>
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge">About Us</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div class="dropdown"  >
  <button class="dropbtn" class="w3-bar w3-white w3-border-bottom w3-xlarge"><i class="fa fa-bars"><?php echo" " .$_SESSION["uname"].""?></i></button>
  <div class="dropdown-content">
    <a href=""><?php echo"" .$_SESSION["uname"].""?></a>
     <a href="logout.php">Logout</a>
    
    <a href="#">Settings</a>
    <a href="#">Help</a>

   
   </div>
</div>
</div>
<!----------------------------------------------Start of Admin Pannel for Insertion------------------------------------------>
<header class="w3-display-container w3-content w3-hide-small" style="max-width:1500px">
  <img class="w3-image" src="img2.jpg" width="100%" height="100%" >
  <div class="w3-display-middle" style="width: 65%; max-width: 65%;min-width: 40%;">
    <div class="w3-bar w3-black">
      
      <button class="w3-bar-item w3-button tablink" onclick="openLink(event, 'Hotel');"><i class="fa fa-eye w3-margin-right">        </i>View</button>
      <button class="w3-bar-item w3-button tablink" onclick="openLink(event, 'Flight');"><i class="fa fa-fighter-jet w3-margin-right"></i>Insert</button>
      <button class="w3-bar-item w3-button tablink" onclick="openLink(event, 'Car');"><i class="fa fa-edit w3-margin-right">       </i>Edit</button>
      <button class="w3-bar-item w3-button tablink" onclick="openLink(event, 'Delete');"><i class="fa fa-remove w3-margin-right">     </i>Delete</button>

    </div>
    <div id="Flight" class="w3-container w3-white w3-padding-16 myLink">
      
      <div class="container">
        <h3>Insert Routes</h3>
  <form action="admin1a.php" method="POST">
    <div class="row">
      <div class="col-25">
        <label for="fname">Flight Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" name="fname" placeholder="Flight Name" " required>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Departure</label>
      </div>
      <div class="col-75">
 <select id="departre" name="departre" required>
        <option value="Islamabad">Islamabad</option>
          <option value="Karachi">Karachi</option>
          <option value="Lahore">Lahore</option>
           <option value="Faislabad">Faislabad</option>
          <option value="Multan">Multan</option>
          <option value="Peshawar">Peshawar</option>
           <option value="Queta">Queta</option>
          <option value="Sialkot">Sialkot</option>
          <option value="Bahawalpur">Bahawalpur</option>
           <option value="Sakardu">Sakardu</option>
          <option value="Sehawan Sharif">Sehawan Sharif</option>
          <option value="Chilas">Chilas</option>
           <option value="Chitral">Chitral</option>
         
        </select>      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Arrival</label>
      </div>
      <div class="col-75">
        <select id="arriving" name="arriving" required>
          <option value="Islamabad">Islamabad</option>
          <option value="Karachi">Karachi</option>
          <option value="Lahore">Lahore</option>
           <option value="Faislabad">Faislabad</option>
          <option value="Multan">Multan</option>
          <option value="Peshawar">Peshawar</option>
           <option value="Queta">Queta</option>
          <option value="Sialkot">Sialkot</option>
          <option value="Bahawalpur">Bahawalpur</option>
           <option value="Sakardu">Sakardu</option>
          <option value="Sehawan Sharif">Sehawan Sharif</option>
          <option value="Chilas">Chilas</option>
           <option value="Chitral">Chitral</option>
         
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">Date and Time</label>
      </div>
      <div class="col-75">
     <!--   <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>-->
         <input type="datetime-local" name="time" id="time" required>
        
      </div>
    </div>
    <div class="row">
      <br>
      <input style="margin:center;" type="submit" value="Submit" >
    </div>
  </form>
</div>


        
       </div>
        <div id="Hotel" class="w3-container w3-white w3-padding-16 myLink">
      
      <h3>Flights Name and Price </h3>  
  <?php 
$query = "SELECT * from Flights  ";
$connection=mysqli_connect("localhost","root","","login");
    $result       =     mysqli_query($connection, $query);
    //$row1=        mysqli_fetch_array($result);?>
<?php 
 ?>
 <br>
<table>
  <tr>
    <th>ID</th>
    <th>Flight Name</th>
    <th>Departure</th>
    <th>Arrival</th>
    <th>Date and Time</th>
    
    <th>Price</th>
  </tr>
 <?php while($row    =     mysqli_fetch_array($result))
    {$id = $row[0];
      $time     =     $row[1];
      $Departure   =     $row[2];
      $Arrival =     $row[3];
      $Flightname      =     $row[4]; ?>
         <td align="center"><?php echo $id; ?></td>
        <td align="center"><?php echo $Flightname; ?></td>
        <td align="center"><?php echo $time; ?></td>
        <td align="center"><?php echo $Departure; ?></td>
        <td align="center"><?php echo $Arrival; ?></td>
        <td align="center"> Updated Soon</td>
         </tr>
  <?php } ?>
</table></div>

    <div id="Car" class="w3-container w3-white w3-padding-16 myLink">
    <div class="container">
      <form action="admin1b.php" method="POST">
       <br><br>

    <div class="row">
      <div class="col-25">
        <label >Id</label>
      </div>
      <div class="col-75">

        <input type="text" id="ide" name="ide" placeholder="Enter Id number of the route which you want to change"  required>
      </div>
    </div>
      
     
    <div class="row">
      <div class="col-25">
        <label for="fname">Flight Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" name="fname" placeholder="Flight Name" " required>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Departure</label>
      </div>
      <div class="col-75">
 <select id="departre" name="departre" required>
        <option value="Islamabad">Islamabad</option>
          <option value="Karachi">Karachi</option>
          <option value="Lahore">Lahore</option>
           <option value="Faislabad">Faislabad</option>
          <option value="Multan">Multan</option>
          <option value="Peshawar">Peshawar</option>
           <option value="Queta">Queta</option>
          <option value="Sialkot">Sialkot</option>
          <option value="Bahawalpur">Bahawalpur</option>
           <option value="Sakardu">Sakardu</option>
          <option value="Sehawan Sharif">Sehawan Sharif</option>
          <option value="Chilas">Chilas</option>
           <option value="Chitral">Chitral</option>
         
        </select>      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Arrival</label>
      </div>
      <div class="col-75">
        <select id="arriving" name="arriving" required>
          <option value="Islamabad">Islamabad</option>
          <option value="Karachi">Karachi</option>
          <option value="Lahore">Lahore</option>
           <option value="Faislabad">Faislabad</option>
          <option value="Multan">Multan</option>
          <option value="Peshawar">Peshawar</option>
           <option value="Queta">Queta</option>
          <option value="Sialkot">Sialkot</option>
          <option value="Bahawalpur">Bahawalpur</option>
           <option value="Sakardu">Sakardu</option>
          <option value="Sehawan Sharif">Sehawan Sharif</option>
          <option value="Chilas">Chilas</option>
           <option value="Chitral">Chitral</option>
         
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">Date and Time</label>
      </div>
      <div class="col-75">
     <!--   <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>-->
         <input type="datetime-local" name="time" id="time" required>
        
      </div>
    </div>
    <div class="row">
      <br>
      <input style="margin:center;" type="submit" value="Submit" >
    </div>
  </form>
</div>


        
       </div>

<div>
  <div id="Delete" class="w3-container w3-white w3-padding-16 myLink">
 <div class="row">
  <form action="admin1d.php" method="POST">
      <div class="col-25">
        <label >Id</label>
      </div>
      <div class="col-75">

        <input type="text" id="ide" name="ide" placeholder="Enter Id number of the route which you want to Delete"  required>
        <br><br>
        <button value="submit" id="sub" class="w3-bar-item w3-button w3-text-red w3-hover-red" >Submit</button>
      </div>
    </div>
      </form>

  </div>
</div>
 
    </div>


    </div>
 

<!---------------------------------------------- End of Admin Pannel for Insertion------------------------------------------>

<script>
// Tabs
function openLink(evt, linkName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("myLink");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
  }
  document.getElementById(linkName).style.display = "block";
  evt.currentTarget.className += " w3-red";
}

// Click on the first tablink on load
document.getElementsByClassName("tablink")[0].click();
</script>
</body>
</html>